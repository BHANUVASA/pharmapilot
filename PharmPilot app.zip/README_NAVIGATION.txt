PHARMPILOT FULLY CONNECTED WEBSITE

Open index.html to start. The top navigation is available on every HTML page:
- PharmPilot Home
- Clinical Pharmacy (15 department pages)
- Future Scope (4 career guides)
- Research & Innovation (research learning guides)

Keep all files in this folder together. PDF guides are local files and are linked from their relevant pages. No existing page content was intentionally removed; a shared navigation bar was added and the homepage Future Scope link was corrected.
