PHARMPILOT — PATHOPHYSIOLOGY UPDATE

HOW TO OPEN
1. Download this ZIP file.
2. Right-click it and choose Extract All (Windows) or use your archive app.
3. Open the extracted folder.
4. Double-click START_HERE.html.
5. Select Pathophysiology — 8 Chapters.

Keep the files and assets folder together after extraction. Do not open HTML files from inside the ZIP preview.

Includes the existing PharmPilot website plus 8 Pathophysiology study pages and the supplied revision PDFs. PDF files are available inside the chapter pages; this start page does not directly link to PDFs.
