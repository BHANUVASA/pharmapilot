PharmPilot Year 5 update

Year 5 now has four subject cards: Clinical Research; Pharmacoepidemiology and Pharmacoeconomics; Clinical Pharmacokinetics & Pharmacotherapeutic Drug Monitoring; Clerkship. Project Work (Six Months) is no longer shown as a Year 5 button.

Clinical Research includes three HTML chapter pages converted from the supplied PDF content, with embedded mind-map images. The three original PDFs are retained as source copies and are not directly linked from the subject menu. The other four subject pages are functional placeholders because no source chapter PDFs/notes for those subjects were included in this update.


Pharmacoepidemiology and Pharmacoeconomics chapter update

Added eight numbered HTML chapter cards/pages: Pharmacoepidemiology definition/scope/origin/evolution; measurement of outcomes; risk; pharmacoepidemiological methods; data sources; pharmacoeconomic evaluations and formulary management; pharmacoeconomic outcome assessment/types; applications/software/case studies. Each HTML page contains readable extracted study content and an embedded PNG rendering of its supplied mind map. All eight original PDFs are retained as source copies and are not linked directly from the subject menu.


Clerkship update: Added six numbered HTML chapter cards/pages from the uploaded PharmD 5th Year Clerkship Guide PDF, with readable source-derived notes and embedded page images. The source PDF is retained inside the ZIP and is not linked directly from the subject menu. Removed the Project Work (Six Months) button from Year 5 and removed the Year 6 button from the Study Materials year selector. The Year 6 page file itself is retained but is no longer linked from that selector.
